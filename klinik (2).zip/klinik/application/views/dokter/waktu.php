<div class="container waktuDokter">
    <h3> Tambah Waktu Kerja Dokter</h3>
    <div class="row">
        <div class="col">
            <form action="">
            <div class="form-group">
                <label for="hari">Hari</label>
                <input type="text" name="hari" class="form-control" id="jam" aria-describedby="emailHelp">
            </div>
            <div class="form-group">
                <label for="jam">Jam</label>
                <input type="jam" name="jam" class="form-control" id="jam" aria-describedby="emailHelp">
            </div>  
                <button type="submit" name="tambah" class="btn btn-warning float-right" >Tambah Data</button>
                <a href="" class="btn btn-outline-warning float-right mr-2">Kembali</a>
            </form>
        </div>

        <div class="col vektor">
            <img src="<?php echo base_url().'assets/img/waktu.svg' ?>" alt="..." class="img-thumbnail">
        </div>
    </div>
</div>